from django.contrib import admin
from django.urls import path

from humans.views import HomeHumans, HumansByProf, ViewHuman, AddHuman, register, user_login, user_logout
#from humans.views import index, get_prof, view_human, add_humans, test

urlpatterns = [
    #path('', index, name='Home'),
    #path('prof/<int:profession_id>', get_prof, name='Prof'),
    #path('humans/<int:human_id>', view_human, name='View_human'),
    #path('humans/add_humans', add_humans, name='Add_humans'),
    # path('test/', test, name='Test'),
    path('', HomeHumans.as_view(), name='Home'),
    path('prof/<int:profession_id>', HumansByProf.as_view(), name='Prof'),
    path('humans/<int:pk>', ViewHuman.as_view(), name='View_human'),
    path('humans/add_humans', AddHuman.as_view(), name='Add_humans'),
    path('register/', register, name='Register'),
    path('login/', user_login, name='Login'),
    path('logout/', user_logout, name='Logout'),
]
